#include <iostream>
#include<GL/gl.h>
#include <windows.h>
#include <GL/glut.h>
#include <math.h>
#include<time.h>
#include <stdlib.h>
using namespace std;
bool day = true;
//bool screenOne=true;
//bool screenTwo=false;
const float PI = 3.14159265f;

void initGL() {
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f); // White background
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    //gluOrtho2D(-50, 50, -50, 50);
    gluOrtho2D(0, 13.4208, 0, 8);
    glMatrixMode(GL_MODELVIEW);
}
void renderBitmapString(float x, float y, float z, void *font, char *string)
{
 glRasterPos3f(x, y, z);
 for (char *c = string; *c != '\0'; c++) {
 glutBitmapCharacter(font, *c);
 }
}

/*....................................... Airplane..........................................*/
float airplane_x = 0.0;       // Start from left side of the screen
float planeSpeed = 0.1f;      // Default normal speed
bool planeMoving = true;      // Plane is moving
bool fastSpeed = false;       // Track if speed is fast


// Function to draw the airplane
void drawAirplane() {
    glPushMatrix();
    glTranslatef(airplane_x, 0.0f, 0.0f);

    if (day){glColor3ub(251, 251, 251); }// Day - white

    else{glColor3ub(180, 180, 180);} // Night - gray/silver
    glBegin(GL_POLYGON);
        glVertex2f(1.66, 5.88); //I17
        glVertex2f(4.57, 5.37);
         glVertex2f(4.97, 5.29);
        glVertex2f(5.13, 5.24);
        glVertex2f(5.19, 5.22);
         glVertex2f(5.2, 5.2);
        glVertex2f(5.06, 5.14);
        glVertex2f(4.74, 5.11);//
        glVertex2f(4.34, 5.09);
        glVertex2f(3.79, 5.09);
        glVertex2f(3.30, 5.13);



        glVertex2f(3.02, 5.15);
        glVertex2f(2.46, 5.30);
        glVertex2f(2.16, 5.33);
        glVertex2f(1.87, 5.38);
        glVertex2f(1.65, 5.43);
        glVertex2f(1.51, 5.48);
        glVertex2f(1.39, 5.54);
        glVertex2f(1.32, 5.59);
        glVertex2f(1.28, 5.63);
        glVertex2f(1.27, 5.66);
        glVertex2f(1.26, 5.69);
        glVertex2f(1.27, 5.71);
        glVertex2f(1.29, 5.73);
        glVertex2f(1.30, 5.75);
        glVertex2f(1.36, 5.76);
        glVertex2f(1.40, 5.77);
        glVertex2f(1.41, 5.78);
        glVertex2f(1.47, 5.83);
        glVertex2f(1.50, 5.84);
        glVertex2f(1.55, 5.87);
        glVertex2f(1.60, 5.88);
        glVertex2f(1.66, 5.88);
    glEnd();



if (day){glColor3ub(237,104,233); }// Day pink
else {glColor3ub(100, 80, 150);}// Night dim pink/purple
    glBegin(GL_POLYGON);
        glVertex2f(2.51, 5.38); //G20
        glVertex2f(2.53, 5.38);
         glVertex2f(2.53, 5.38);
        glVertex2f(2.53, 5.35);
        glVertex2f(2.52, 5.33);
         glVertex2f(2.51, 5.31);
        glVertex2f(2.50, 5.28);
        glVertex2f(2.50, 5.25);
        glVertex2f(2.50, 5.22);
         glVertex2f(2.50, 5.20);
          glVertex2f(2.50, 5.17);
         glVertex2f(2.48, 5.18);
          glVertex2f(2.46, 5.20);
         glVertex2f(2.46, 5.23);
          glVertex2f(2.46, 5.26);
         glVertex2f(2.46, 5.30);
          glVertex2f(2.48, 5.33);
         glVertex2f(2.49, 5.36);
          glVertex2f(2.51, 5.38);

    glEnd();
if (day){glColor3ub(237,104,233);} // Day pink
else {glColor3ub(100, 80, 150); } // Night dim pink/purple
    glBegin(GL_POLYGON);
        glVertex2f(2.97, 5.30); //E19
        glVertex2f(3.02, 5.28);
         glVertex2f(3.02, 5.25);
        glVertex2f(3.02, 5.21);
        glVertex2f(3.02, 5.18);
         glVertex2f(3.01, 5.14);
        glVertex2f(3.00, 5.11);
        glVertex2f(2.94, 5.11);//
        glVertex2f(2.96, 5.15);
         glVertex2f(2.97, 5.18);
          glVertex2f(2.97, 5.21);
         glVertex2f(2.97, 5.24);
          glVertex2f(2.97, 5.30);

    glEnd();

glColor3ub(245,245,245);
    glBegin(GL_POLYGON);
         glVertex2f(2.97, 5.30); //E19
        glVertex2f(3.02, 5.28);
         glVertex2f(3.02, 5.25);
        glVertex2f(3.02, 5.21);
        glVertex2f(3.02, 5.18);
         glVertex2f(3.01, 5.14);
        glVertex2f(3.00, 5.11);
        glVertex2f(2.94, 5.11);//
        glVertex2f(2.88, 5.12);
        glVertex2f(2.82, 5.12);
        glVertex2f(2.78, 5.12);
        glVertex2f(2.73, 5.12);
        glVertex2f(2.68, 5.12);
        glVertex2f(2.64, 5.13);
        glVertex2f(2.58, 5.14);
        glVertex2f(2.53, 5.16);
        glVertex2f(2.50, 5.17);
        glVertex2f(2.50, 5.22);
        glVertex2f(2.50, 5.25);
        glVertex2f(2.50, 5.28);
        glVertex2f(2.51, 5.31);
         glVertex2f(2.52, 5.33);
        glVertex2f(2.53, 5.35);
        glVertex2f(2.54, 5.37);
         glVertex2f(2.6, 5.4);
        glVertex2f(2.69, 5.37);
        glVertex2f(2.79, 5.35);
        glVertex2f(2.90, 5.32);
        glVertex2f(2.97, 5.30);


    glEnd();

if (day){glColor3ub(237,104,233);}// Day pink
else{glColor3ub(100, 80, 150);}// Night dim pink/purple
    glBegin(GL_POLYGON);
        glVertex2f(2.97, 5.30); //E19
        glVertex2f(3.02, 5.28);
         glVertex2f(3.02, 5.25);
        glVertex2f(3.02, 5.21);
        glVertex2f(3.02, 5.18);
         glVertex2f(3.01, 5.14);
        glVertex2f(3.00, 5.11);
        glVertex2f(2.94, 5.11);//
        glVertex2f(2.96, 5.15);
         glVertex2f(2.97, 5.18);
          glVertex2f(2.97, 5.21);
         glVertex2f(2.97, 5.24);
          glVertex2f(2.97, 5.30);

    glEnd();


glColor3ub(245,245,245);
    glBegin(GL_POLYGON);
         glVertex2f(2.6, 5.4); //Z18
        glVertex2f(3.75, 5.52);
         glVertex2f(3.76, 5.56);
        glVertex2f(3.9061535396907, 5.65);
        glVertex2f(3.8242625756757, 5.45);
         glVertex2f(3.0608274595354, 5.25);
        glVertex2f(3.0279111657499, 5.25);
        glVertex2f(3.0253149095527, 5.28);//
        glVertex2f(2.9749292817076, 5.30);
        glVertex2f(2.9041525714816, 5.32);
        glVertex2f(2.7924931618866, 5.35);
        glVertex2f(2.6927124128868, 5.37);
        glVertex2f(2.6, 5.4);


    glEnd();


if (day){glColor3ub(237,104,233);}// Day pink
else {glColor3ub(100, 80, 150);}// Night dim pink/purple
    glBegin(GL_POLYGON);
         glVertex2f(2.5562734554426, 5.42); //S18
        glVertex2f(3.760863119664, 5.63);
         glVertex2f(3.751279400882, 5.60);
        glVertex2f(2.6, 5.4);
        glVertex2f(2.5562734554426, 5.42);


    glEnd();


   glLineWidth(5);
    glColor3ub(237,237,237);
    glBegin(GL_LINE_LOOP);
        glVertex2f(3.0608274595354, 5.25);
        glVertex2f(3.8242625756757, 5.45);

    glEnd();

    glLineWidth(5);
    glColor3ub(237,237,237);
    glBegin(GL_LINE_LOOP);
       glVertex2f(3.8242625756757, 5.45);
        glVertex2f(3.9061535396907, 5.65);
    glEnd();

    glLineWidth(5);
    glColor3ub(237,237,237);
    glBegin(GL_LINE_LOOP);
        glVertex2f(3.9061535396907, 5.65);
        glVertex2f(3.760863119664, 5.6);
    glEnd();

    glLineWidth(5);
    glColor3ub(237,237,237); //shade
    glBegin(GL_LINE_LOOP);
        glVertex2f(2.5613118765406, 5.38);
        glVertex2f(2.9730678476031, 5.28);
    glEnd();

    glColor3ub(241,241,241); //shade
    glBegin(GL_POLYGON);
        glVertex2f(1.2878571537056, 5.63);//K18
        glVertex2f(2.5117493213891, 5.38);
         glVertex2f(2.5117493213891, 5.38);
        glVertex2f(2.494610301792, 5.36);
         glVertex2f(2.4815520011466, 5.33);
        glVertex2f(2.4697863639185, 5.30);
         glVertex2f(2.1688459170059, 5.33);
        glVertex2f(1.8755906096085, 5.38);
        glVertex2f(1.6582541888978, 5.43);
        glVertex2f(1.5123708380097, 5.48);
                 glVertex2f(1.3962595995478, 5.54);
        glVertex2f(1.329272346589, 5.59);
        glVertex2f(1.2878571537056, 5.6329397757455);
    glEnd();

      glColor3ub(241,241,241); //shade
    glBegin(GL_POLYGON);
        glVertex2f(3.28, 5.31);//U56
        glVertex2f(3.5023822928558, 5.26);
         glVertex2f(3.6897990956967, 5.23);
        glVertex2f(3.9205306584196, 5.20);
         glVertex2f(4.1687531474011, 5.18);
        glVertex2f(4.3707468126852, 5.18);
         glVertex2f(4.5875900530778, 5.17);
        glVertex2f(4.89, 5.18);
        glVertex2f(5.02798029791271, 5.17);
        glVertex2f(5.15, 5.24);
                 glVertex2f(5.1939224850182, 5.22);
        glVertex2f(5.2, 5.2);
        glVertex2f(5.1977856100596, 5.181);
        glVertex2f(5.1792426098608, 5.15);//U56
        glVertex2f(5.0648941086354, 5.14);
         glVertex2f(4.7491834916849, 5.11);
        glVertex2f(4.3435256422176, 5.09);
         glVertex2f(3.7987599195626, 5.09);
        glVertex2f(3.3035670037113, 5.13);
         glVertex2f(3.0226990310646, 5.15);
        glVertex2f(3.0251917003153, 5.18);
        glVertex2f(3.0279111657499, 5.21);
        glVertex2f(3.0279111657499, 5.25);
        glVertex2f(3.0608274595354, 5.25);
        glVertex2f(3.28, 5.31);

    glEnd();


    if (day) {glColor3ub(237,104,233);} // Day pink
else {glColor3ub(100, 80, 150);} // Night dim pink/purple
    glBegin(GL_POLYGON);
        glVertex2f(4.6210181652645, 5.38);
        glVertex2f(4.6210181652645, 5.37);
         glVertex2f(4.6783324383219, 5.38);
        glVertex2f(4.7423666710595, 5.40);
        glVertex2f(5.1799336204354, 5.85);
         glVertex2f(5.4413111136284, 5.81);
        glVertex2f(5.1650675100833, 5.31);
        glVertex2f(5.13, 5.24);
        glVertex2f(4.9725377991169, 5.29);
         glVertex2f(4.6224980989278, 5.38);

    glEnd();

if (day) {glColor3ub(237,104,233); } // Day pink
else  {glColor3ub(100, 80, 150);} // Night dim pink/purple
    glBegin(GL_POLYGON);
        glVertex2f(5.2060849897348, 5.37); //P17
        glVertex2f(5.3847323329274, 5.37);
         glVertex2f(5.02798029791271, 5.17);
        glVertex2f(4.8272454515201, 5.18);
        glVertex2f(4.72116606115, 5.20);
         glVertex2f(4.6917902299706, 5.23);
        glVertex2f(5.2060849897348, 5.37);


    glEnd();


    glLineWidth(1);
    glColor3ub(0,0,0);
    glBegin(GL_LINE_LOOP);
        glVertex2f(1.7656390907886, 5.81);
        glVertex2f(1.8363283846312, 5.79);

    glEnd();

     glLineWidth(1);
    glColor3ub(0,0,0);
    glBegin(GL_LINE_LOOP);
        glVertex2f(1.8363283846312, 5.79);
        glVertex2f(1.7915249232228, 5.62);

    glEnd();


     glLineWidth(1);
    glColor3ub(0,0,0);
    glBegin(GL_LINE_LOOP);
        glVertex2f(1.7915249232228, 5.62);
        glVertex2f(1.7180331501087, 5.64);

    glEnd();

     glLineWidth(1);
    glColor3ub(0,0,0);
    glBegin(GL_LINE_LOOP);
        glVertex2f(1.7180331501087, 5.64);
        glVertex2f(1.7656390907886, 5.81);

    glEnd();



float angleDegrees = -10;
float angleRadians = angleDegrees * (PI / 180);  // Convert to radians
float stepSize = 0.06;

for (int i = 0; i < 42; i++) {
    if (i >= 16 && i <= 31) {
        continue; // Skip drawing windows from index 16 to 31
    }

    float dx = cos(angleRadians) * stepSize * i;
    float dy = sin(angleRadians) * stepSize * i;

    glPushMatrix();                // Save current matrix
    glTranslatef(dx, dy, 0.0);    // Apply translation

    glColor3ub(0, 0, 0); // window
    glBegin(GL_POLYGON);
        glVertex2f(1.9110587193306, 5.67);  // T22
        glVertex2f(1.916078735152, 5.71);
        glVertex2f(1.9543312266048, 5.71);
        glVertex2f(1.9498651269646, 5.67);
        glVertex2f(1.9110587193306, 5.67);  // Close polygon
    glEnd();

    glPopMatrix();                 // Restore original matrix
}



     glColor3ub(0, 0, 0);
    glBegin(GL_POLYGON);
        glVertex2f(1.4769940883223, 5.83);  //C18
        glVertex2f(1.4953000204163, 5.83);
        glVertex2f(1.5176482360856, 5.83);
        glVertex2f(1.5417492529839, 5.82);
        glVertex2f(1.5658502698822, 5.81);
        glVertex2f(1.5899512867805, 5.81);
        glVertex2f(1.605288297534, 5.79);
        glVertex2f(1.6056875072324, 5.78);
        glVertex2f(1.597086439053, 5.76);
        glVertex2f(1.5873755556246, 5.74);
        glVertex2f(1.5750524763343, 5.74);
        glVertex2f(1.5552560028985, 5.74);
        glVertex2f(1.5246425400579, 5.74);
        glVertex2f(1.4891953725583, 5.749);
        glVertex2f(1.4573734835529, 5.75);
        glVertex2f(1.4307881079282, 5.76);
        glVertex2f(1.4047712720922, 5.77);
        glVertex2f(1.4769940883223, 5.83); // Close polygon
    glEnd();


    glPopMatrix();
}















void drawTwinklingStars() {
    glPointSize(2);
    glBegin(GL_POINTS);

    for (int i = 0; i < 10; ++i) {
        float x = (rand() % 1300) / 100.0f; // 0 to 13
        float y = 6.5f + (rand() % 150) / 100.0f; // 6.5 to 8
        glColor3ub(200 + rand() % 56, 200 + rand() % 56, 200 + rand() % 56); // vary brightness
        glVertex2f(x, y);
    }

    glEnd();
}
void drawStars() {
    glPointSize(2); // Size of each star
    glBegin(GL_POINTS);
    glColor3ub(255, 255, 255); // White stars

    // Stars drawn m
    glVertex2f(1.2f, 7.6f);
    glVertex2f(2.5f, 7.3f);
    glVertex2f(3.8f, 7.8f);
    glVertex2f(5.1f, 7.5f);
    glVertex2f(6.0f, 7.7f);
    glVertex2f(7.5f, 7.4f);
    glVertex2f(8.9f, 7.6f);
    glVertex2f(10.2f, 7.9f);
    glVertex2f(11.4f, 7.2f);
    glVertex2f(12.6f, 7.8f);

    glVertex2f(0.51, 5.57);
    glVertex2f(1.45, 4.468);
    glVertex2f(4.54, 4.26);
    glVertex2f(4.56, 6.08);
    glVertex2f(3.60, 6.08);
    glVertex2f(8, 5);

    glVertex2f(8.05, 5.84);
    glVertex2f(7.70, 6.78);
    glVertex2f(9.66, 4.59);
    glVertex2f(10.21, 5.35);
    glVertex2f(11, 4);
    glVertex2f(12.33, 6.84);

     glVertex2f(6.66, 5.53);
    glVertex2f(3.24, 5.06);
    glVertex2f(2.44, 5.83);


    glEnd();
}



/**....................................... Car..........................................**/
float car_x = 0.0;
float car_speed = 0.02;  // Adjust speed to match airplane

// Function to draw the car
void drawCAR() {
    glPushMatrix();
    glTranslatef(car_x, 0.0f, 0.0f);


 if (day){
    glColor3ub(215,171,37);    // Yellow
   }
else{
    glColor3ub(127,90,10);     // Night yellow
    }
    glBegin(GL_POLYGON);
        glVertex2f(5.35, 1.30);
        glVertex2f(5.62, 1.31);
         glVertex2f(5.74, 1.31);
        glVertex2f(6.14, 1.31);
        glVertex2f(6.23, 1.29);
         glVertex2f(6.20, 1.26);
        glVertex2f(6.33, 1.10);
        glVertex2f(6.34, 1.07);
        glVertex2f(6.35, 0.98);
        glVertex2f(6.34, 0.97);
        glVertex2f(6.34, 0.92);
        glVertex2f(6.38, 0.90);
        glVertex2f(6.38, 0.70);
        glVertex2f(6.27, 0.70); //

        glVertex2f(5.97, 0.70);
        glVertex2f(5.17, 0.70);

        glVertex2f(4.87, 0.70);
        glVertex2f(4.7, 0.70);
         glVertex2f(4.66, 0.72);
        glVertex2f(4.66, 0.85);
        glVertex2f(4.68, 0.93);
         glVertex2f(4.73, 0.96);
        glVertex2f(4.85, 1.02);
        glVertex2f(5.00, 1.06);
        glVertex2f(5.13, 1.10);
        glVertex2f(5.35, 1.30);
    glEnd();

   /**.....................CarWheel1..............**/
GLfloat x1 = 5.02;
GLfloat y1 = 0.74;
GLfloat radius1 = 0.13;
int triangleAmount1 = 100;
GLfloat twicePi1 = 2.0 * PI;

glColor3ub(0, 0, 0); // Black
glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x1, y1);  // center
    for (int i = 0; i <= triangleAmount1; i++) {
        glVertex2f(
            x1 + (radius1 * cos(i * twicePi1 / triangleAmount1)),
            y1 + (radius1 * sin(i * twicePi1 / triangleAmount1))
        );
    }
glEnd();

GLfloat x2 = 5.02f;       // Same X-coordinate as before
GLfloat y2 = 0.74f;       // Same Y-coordinate as before
GLfloat radius2 = 0.07f;   // Smaller radius (0.07 instead of 0.13)
int triangleAmount2 = 100; // Same smoothness
GLfloat twicePi2 = 2.0f * PI;

glColor3ub(255, 255, 255);      // Black
glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x2, y2);    // Center remains the same
    for (int i = 0; i <= triangleAmount2; i++) {
        glVertex2f(
            x2 + (radius2 * cos(i * twicePi2 / triangleAmount2)),
            y2 + (radius2 * sin(i * twicePi2 / triangleAmount2))
        );
    }
glEnd();


 /**.....................CarWheel2..............**/
GLfloat x3 = 6.12;
GLfloat y3 = 0.74;
GLfloat radius3 = 0.13;
int triangleAmount3 = 100;
GLfloat twicePi3 = 2.0 * PI;

glColor3ub(0, 0, 0); // Black
glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x3, y3);  // center
    for (int i = 0; i <= triangleAmount3; i++) {
        glVertex2f(
            x3 + (radius3 * cos(i * twicePi3 / triangleAmount3)),
            y3 + (radius3 * sin(i * twicePi3 / triangleAmount3))
        );
    }
glEnd();

GLfloat x4 = 6.12;       // Same X-coordinate as before
GLfloat y4 = 0.74;       // Same Y-coordinate as before
GLfloat radius4 = 0.07;   // Smaller radius (0.07 instead of 0.13)
int triangleAmount4 = 100; // Same smoothness
GLfloat twicePi4 = 2.0 * PI;

glColor3ub(255, 255, 255);      // Black
glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x4, y4);    // Center remains the same
    for (int i = 0; i <= triangleAmount4; i++) {
        glVertex2f(
            x4 + (radius4 * cos(i * twicePi4 / triangleAmount4)),
            y4 + (radius4 * sin(i * twicePi4 / triangleAmount4))
        );
    }
glEnd();

 if (day){
    glColor3ub(2,92,111);    // Glass
   }
else{
    glColor3ub(10,20,20);     // Night Black
    }
    glBegin(GL_POLYGON);
        glVertex2f(5.38, 1.26);
        glVertex2f(5.71, 1.26);
         glVertex2f(6.08, 1.26);
        glVertex2f(6.21, 1.12);
        glVertex2f(6.14, 1.06);
         glVertex2f(5.24, 1.06);
        glVertex2f(5.2, 1.1);
        glVertex2f(5.38, 1.26);

    glEnd();



 glLineWidth(5);
    //glColor3ub(83,55,11);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.16, 1.08);
        glVertex2f(5.40, 1.25);
    glEnd();
 glLineWidth(5);
    //glColor3ub(83,55,11);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.16, 1.05);
        glVertex2f(6.11, 1.05);
    glEnd();
glLineWidth(4);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(6.10, 1.04);
        glVertex2f(6.20, 1.12);
    glEnd();
glLineWidth(5);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(6.19, 1.11);
        glVertex2f(6.07, 1.25);
    glEnd();
glLineWidth(4);
 if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(6.07, 1.25);
        glVertex2f(5.40, 1.25);
    glEnd();

    glLineWidth(2);
 if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.71, 1.25);
        glVertex2f(5.63, 1.06);
    glEnd();

        glLineWidth(2);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.63, 1.06);
        glVertex2f(5.63, 0.75);
    glEnd();


glLineWidth(2);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.17, 1.0);
        glVertex2f(6.13, 1.0);
    glEnd();

    glLineWidth(2);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.17, 1.0);
        glVertex2f(5.17, 0.75);
    glEnd();

       glLineWidth(2);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.17, 0.75);
        glVertex2f(5.93, 0.75);
    glEnd();

       glLineWidth(2);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.93, 0.75);
        glVertex2f(6.11, 1.01);
    glEnd();

if (day){
    glColor3ub(2,92,111);    // Glass
   }
else{
    glColor3ub(10,20,20);     // Night Black
    }
    glBegin(GL_POLYGON);
        glVertex2f(6.18, 1.24);
        glVertex2f(6.20, 1.26);
         glVertex2f(6.33, 1.10);
        glVertex2f(6.18, 1.24);


    glEnd();

if (day){
    glColor3ub(223,88,26);    // Orange light
   }
else{
    glColor3ub(178,56,0);     // Night Black
    }
    glBegin(GL_POLYGON);
        glVertex2f(6.33, 1.10);
        glVertex2f(6.27, 1.10);
         glVertex2f(6.26, 1.09);
        glVertex2f(6.26, 1.06);
        glVertex2f(6.28, 1.03);
         glVertex2f(6.30, 1.00);
        glVertex2f(6.34, 0.97);
        glVertex2f(6.35, 0.98);
         glVertex2f(6.34, 1.07);
        glVertex2f(6.33, 1.10);


    glEnd();

    if (day){
    glColor3ub(223,88,26);    // Orange light
   }
else{
    glColor3ub(178,56,0);     // Night Black
    }
    glBegin(GL_POLYGON);
        glVertex2f(6.38, 0.86);
        glVertex2f(6.35, 0.83 );
         glVertex2f(6.35, 0.8);
        glVertex2f(6.38, 0.78);
        glVertex2f(6.38, 0.86);
glEnd();

glLineWidth(3);
     if (day){
    glColor3ub(10,10,10);    // Day green
}
else{
    glColor3ub(0,0,0);     // Night green (darker)
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(4.71, 0.75);
        glVertex2f(4.66, 0.75);
    glEnd();

    if (day){
    glColor3ub(238,238,238);    // White light
   }
else{
    glColor3ub(204,200,200);     // Night Black
    }
    glBegin(GL_POLYGON);
        glVertex2f(4.70, 0.90);
        glVertex2f(4.726, 0.92 );
         glVertex2f(4.85, 0.96);
        glVertex2f(4.85, 0.87);
        glVertex2f(4.69, 0.86);
        glVertex2f(4.70, 0.90);
    glEnd();

if (day){
    glColor3ub(215,171,37);    // Yellow
   }
else{
    glColor3ub(127,90,10);     // Night yellow
    }
    glBegin(GL_POLYGON);
        glVertex2f(5.62, 1.31);
        glVertex2f(5.65, 1.36);
         glVertex2f(5.74, 1.36);
        glVertex2f(5.76, 1.31);
        glVertex2f(5.62, 1.31); //

    glEnd();





    glPopMatrix();
}

/**.......................................Car2 Scale..........................................**/


bool car2Moving = true;       // Initially moving
float car2PositionX = 0.0f;   // Initial X position

void drawCAR2() {
    glPushMatrix();
    glTranslatef(4.50f + car2PositionX, -0.40f, 0.0f);  // Add dynamic movement
    glScalef(-0.7f, 0.7f, 1.0f);         // Scale to 70%

    //drawCAR();  // Reuse your existing drawCAR logic

 if (day){
    glColor3ub(188,18,18);    // Red
   }
else{
    glColor3ub(129,14,14);     // Night yellow
    }
    glBegin(GL_POLYGON);
        glVertex2f(5.35, 1.31);
         glVertex2f(5.74, 1.31);
        glVertex2f(6.14, 1.31);
        glVertex2f(6.23, 1.29);
         glVertex2f(6.20, 1.26);
        glVertex2f(6.33, 1.10);
        glVertex2f(6.34, 1.07);
        glVertex2f(6.35, 0.98);
        glVertex2f(6.34, 0.97);
        glVertex2f(6.34, 0.92);
        glVertex2f(6.38, 0.90);
        glVertex2f(6.38, 0.70);
        glVertex2f(6.27, 0.70); //

        glVertex2f(5.97, 0.70);
        glVertex2f(5.17, 0.70);

        glVertex2f(4.87, 0.70);
        glVertex2f(4.7, 0.70);
         glVertex2f(4.66, 0.72);
        glVertex2f(4.66, 0.85);
        glVertex2f(4.68, 0.93);
         glVertex2f(4.73, 0.96);
        glVertex2f(4.85, 1.02);
        glVertex2f(5.00, 1.06);
        glVertex2f(5.13, 1.10);
        glVertex2f(5.35, 1.31);
    glEnd();

   /**.....................CarWheel1..............**/
GLfloat x1 = 5.02;
GLfloat y1 = 0.74;
GLfloat radius1 = 0.13;
int triangleAmount1 = 100;
GLfloat twicePi1 = 2.0 * PI;

glColor3ub(0, 0, 0); // Black
glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x1, y1);  // center
    for (int i = 0; i <= triangleAmount1; i++) {
        glVertex2f(
            x1 + (radius1 * cos(i * twicePi1 / triangleAmount1)),
            y1 + (radius1 * sin(i * twicePi1 / triangleAmount1))
        );
    }
glEnd();

GLfloat x2 = 5.02f;       // Same X-coordinate as before
GLfloat y2 = 0.74f;       // Same Y-coordinate as before
GLfloat radius2 = 0.07f;   // Smaller radius (0.07 instead of 0.13)
int triangleAmount2 = 100; // Same smoothness
GLfloat twicePi2 = 2.0f * PI;

glColor3ub(255, 255, 255);      // Black
glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x2, y2);    // Center remains the same
    for (int i = 0; i <= triangleAmount2; i++) {
        glVertex2f(
            x2 + (radius2 * cos(i * twicePi2 / triangleAmount2)),
            y2 + (radius2 * sin(i * twicePi2 / triangleAmount2))
        );
    }
glEnd();


 /**.....................CarWheel2..............**/
GLfloat x3 = 6.12;
GLfloat y3 = 0.74;
GLfloat radius3 = 0.13;
int triangleAmount3 = 100;
GLfloat twicePi3 = 2.0 * PI;

glColor3ub(0, 0, 0); // Black
glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x3, y3);  // center
    for (int i = 0; i <= triangleAmount3; i++) {
        glVertex2f(
            x3 + (radius3 * cos(i * twicePi3 / triangleAmount3)),
            y3 + (radius3 * sin(i * twicePi3 / triangleAmount3))
        );
    }
glEnd();

GLfloat x4 = 6.12;       // Same X-coordinate as before
GLfloat y4 = 0.74;       // Same Y-coordinate as before
GLfloat radius4 = 0.07;   // Smaller radius (0.07 instead of 0.13)
int triangleAmount4 = 100; // Same smoothness
GLfloat twicePi4 = 2.0 * PI;

glColor3ub(255, 255, 255);      // Black
glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x4, y4);    // Center remains the same
    for (int i = 0; i <= triangleAmount4; i++) {
        glVertex2f(
            x4 + (radius4 * cos(i * twicePi4 / triangleAmount4)),
            y4 + (radius4 * sin(i * twicePi4 / triangleAmount4))
        );
    }
glEnd();

 if (day){
    glColor3ub(2,92,111);    // Glass
   }
else{
    glColor3ub(10,20,20);     // Night Black
    }
    glBegin(GL_POLYGON);
        glVertex2f(5.38, 1.26);
        glVertex2f(5.71, 1.26);
         glVertex2f(6.08, 1.26);
        glVertex2f(6.21, 1.12);
        glVertex2f(6.14, 1.06);
         glVertex2f(5.24, 1.06);
        glVertex2f(5.2, 1.1);
        glVertex2f(5.38, 1.26);

    glEnd();



 glLineWidth(5);
    //glColor3ub(83,55,11);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.16, 1.08);
        glVertex2f(5.40, 1.25);
    glEnd();
 glLineWidth(5);
    //glColor3ub(83,55,11);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.16, 1.05);
        glVertex2f(6.11, 1.05);
    glEnd();
glLineWidth(4);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(6.10, 1.04);
        glVertex2f(6.20, 1.12);
    glEnd();
glLineWidth(5);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(6.19, 1.11);
        glVertex2f(6.07, 1.25);
    glEnd();
glLineWidth(4);
 if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(6.07, 1.25);
        glVertex2f(5.40, 1.25);
    glEnd();

    glLineWidth(2);
 if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.71, 1.25);
        glVertex2f(5.63, 1.06);
    glEnd();

        glLineWidth(2);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.63, 1.06);
        glVertex2f(5.63, 0.75);
    glEnd();


glLineWidth(2);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.17, 1.0);
        glVertex2f(6.13, 1.0);
    glEnd();

    glLineWidth(2);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.17, 1.0);
        glVertex2f(5.17, 0.75);
    glEnd();

       glLineWidth(2);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.17, 0.75);
        glVertex2f(5.93, 0.75);
    glEnd();

       glLineWidth(2);
if (day){
    glColor3ub(10,10,10);    // Glass side black border
}
else{
    glColor3ub(10,10,10);
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(5.93, 0.75);
        glVertex2f(6.11, 1.01);
    glEnd();

if (day){
    glColor3ub(2,92,111);    // Glass
   }
else{
    glColor3ub(10,20,20);     // Night Black
    }
    glBegin(GL_POLYGON);
        glVertex2f(6.18, 1.24);
        glVertex2f(6.20, 1.26);
         glVertex2f(6.33, 1.10);
        glVertex2f(6.18, 1.24);


    glEnd();

if (day){
    glColor3ub(223,88,26);    // Orange light
   }
else{
    glColor3ub(178,56,0);     // Night Black
    }
    glBegin(GL_POLYGON);
        glVertex2f(6.33, 1.10);
        glVertex2f(6.27, 1.10);
         glVertex2f(6.26, 1.09);
        glVertex2f(6.26, 1.06);
        glVertex2f(6.28, 1.03);
         glVertex2f(6.30, 1.00);
        glVertex2f(6.34, 0.97);
        glVertex2f(6.35, 0.98);
         glVertex2f(6.34, 1.07);
        glVertex2f(6.33, 1.10);


    glEnd();

    if (day){
    glColor3ub(223,88,26);    // Orange light
   }
else{
    glColor3ub(178,56,0);     // Night Black
    }
    glBegin(GL_POLYGON);
        glVertex2f(6.38, 0.86);
        glVertex2f(6.35, 0.83 );
         glVertex2f(6.35, 0.8);
        glVertex2f(6.38, 0.78);
        glVertex2f(6.38, 0.86);
glEnd();

glLineWidth(3);
     if (day){
    glColor3ub(10,10,10);    // Day green
}
else{
    glColor3ub(0,0,0);     // Night green (darker)
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(4.71, 0.75);
        glVertex2f(4.66, 0.75);
    glEnd();

    if (day){
    glColor3ub(238,238,238);    // White light
   }
else{
    glColor3ub(204,200,200);     // Night Black
    }
    glBegin(GL_POLYGON);
        glVertex2f(4.70, 0.90);
        glVertex2f(4.726, 0.92 );
         glVertex2f(4.85, 0.96);
        glVertex2f(4.85, 0.87);
        glVertex2f(4.69, 0.86);
        glVertex2f(4.70, 0.90);
    glEnd();





    glPopMatrix();
}


void display()
{

    /**........................................ Sky ...........................................**/
   if (day) {
    glColor3ub(205, 240, 255);  // Day sky (light blue)
} else {
    glColor3ub(10, 10, 40);     // Night sky (dark blue/purple)
}
glBegin(GL_QUADS);
glVertex2f(0, 0);
glVertex2f(0, 8);
glVertex2f(13.4208, 8);
glVertex2f(13.4208, 0);
glEnd();

     /**........................................Road...........................................**/
    //glColor3ub(52,52,52);
    if (day){
    glColor3ub(52,52,52); // Light gray in day
}
else{
    glColor3ub(6,0,0);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(0,0);
    glVertex2f(0, 0.85);
    glVertex2f(13.4208, 0.85);
    glVertex2f(13.4208, 0);
    glEnd();

     /**....................................... Sun ..........................................**/
GLfloat x = 3.41;
GLfloat y = 7.05;
GLfloat radius = 0.60;
int triangleAmount = 100;
GLfloat twicePi = 2.0f * PI;

if (day) {
    glColor3ub(244,155,54); // Sun - Orange
    glBegin(GL_TRIANGLE_FAN);
        glVertex2f(x, y);
        for (int i = 0; i <= triangleAmount; i++) {
            glVertex2f(
                x + (radius * cos(i * twicePi / triangleAmount)),
                y + (radius * sin(i * twicePi / triangleAmount))
            );
        }
    glEnd();
}
else {
    glColor3ub(226,201,110); // Moon - light gray/white
    glBegin(GL_TRIANGLE_FAN);
        glVertex2f(x, y);
        for (int i = 0; i <= triangleAmount; i++) {
            glVertex2f(
                x + (radius * cos(i * twicePi / triangleAmount)),
                y + (radius * sin(i * twicePi / triangleAmount))
            );
        }
    glEnd();

    // Optional: crescent effect (overlay dark circle)
    glColor3ub(10, 10, 40); // Night sky color to "cut" the moon
    glBegin(GL_TRIANGLE_FAN);
        glVertex2f(x + radius * 0.3f, y);  // slightly offset to make crescent
        for (int i = 0; i <= triangleAmount; i++) {
            glVertex2f(
                x + radius * 0.8f * cos(i * twicePi / triangleAmount) + radius * 0.3f,
                y + radius * 0.8f * sin(i * twicePi / triangleAmount)
            );
        }
    glEnd();
}
/**.......................................Cloud1..........................................**/



    // Move the cloud using a static offset variable
    static float cloudOffsetX = 0.0;
    cloudOffsetX += 0.001;   // slower speed, adjust as needed
    if (cloudOffsetX > 13.4208)
        cloudOffsetX = -2.0;

    glPushMatrix();
    glTranslatef(cloudOffsetX, 0.0, 0.0); // Horizontal cloud movement

    // Cloud Drawing
    glColor3ub(255, 255, 255);
    glBegin(GL_POLYGON);
        glVertex2f(0.60, 6.50);
        glVertex2f(0.58, 6.52);
        glVertex2f(0.61, 6.56);
        glVertex2f(0.663, 6.57);
        glVertex2f(0.71, 6.57);
        glVertex2f(0.75, 6.57);
        glVertex2f(0.74, 6.62);
        glVertex2f(0.75, 6.66);
        glVertex2f(0.76, 6.71);
        glVertex2f(0.80, 6.76);
        glVertex2f(0.84, 6.80);
        glVertex2f(0.90, 6.81);
        glVertex2f(0.98, 6.80);
        glVertex2f(1.02, 6.79);
         glVertex2f(1.02, 6.83);
        glVertex2f(1.04, 6.88);
        glVertex2f(1.07, 6.93);
        glVertex2f(1.12, 6.96);
        glVertex2f(1.17, 6.99);
        glVertex2f(1.22, 7.01);
        glVertex2f(1.29, 7.02);
        glVertex2f(1.35, 7.03);
        glVertex2f(1.41, 7.02);
        glVertex2f(1.46, 7.01);
        glVertex2f(1.52, 6.99);
        glVertex2f(1.56, 6.96);
        glVertex2f(1.59, 6.93);
        glVertex2f(1.62, 6.89);
         glVertex2f(1.64, 6.85);
         glVertex2f(1.66, 6.81);
        glVertex2f(1.67, 6.79);
        glVertex2f(1.71, 6.83);
        glVertex2f(1.75, 6.84);
        glVertex2f(1.80, 6.85);
        glVertex2f(1.85, 6.84);
        glVertex2f(1.90, 6.81);
        glVertex2f(1.93, 6.791);
        glVertex2f(1.95, 6.76);
        glVertex2f(1.97, 6.73);
        glVertex2f(2.01, 6.73);
        glVertex2f(2.06, 6.74);
        glVertex2f(2.11, 6.73);
        glVertex2f(2.16, 6.71);
        glVertex2f(2.20, 6.70);
        glVertex2f(2.24, 6.67);
        glVertex2f(2.28, 6.65);
        glVertex2f(2.30, 6.62);
        glVertex2f(2.30, 6.58);
        glVertex2f(2.23, 6.53);
        glVertex2f(2.07, 6.49);
         glVertex2f(1.92, 6.45);
        glVertex2f(1.79, 6.44);
        glVertex2f(1.64, 6.43);
        glVertex2f(1.48, 6.42);
        glVertex2f(1.30, 6.42);
        glVertex2f(1.10, 6.43);
        glVertex2f(0.90, 6.44);
        glVertex2f(0.74, 6.46);
        glVertex2f(0.60, 6.50);
    glEnd();

    glPopMatrix();

    glutPostRedisplay(); // Continuously update for animation



/**.......................................Cloud2..........................................**/

// Move the second cloud using a static offset variable (same logic as cloud1)
static float cloudOffsetX2 = 0.0f;
const float cloudWidth = 1.2f;

cloudOffsetX2 += 0.001f;
if (cloudOffsetX2 > 13.4208f + cloudWidth)
    cloudOffsetX2 = +cloudWidth;

glPushMatrix();
glTranslatef(cloudOffsetX2 , 0.0f, 0.0f);  // Shift cloud so its left edge starts at 0


// Cloud2 Drawing
glColor3ub(255, 255, 255);
glBegin(GL_POLYGON);
    glVertex2f(5.81, 7.17);
    glVertex2f(5.83, 7.21);
    glVertex2f(5.90, 7.24);
    glVertex2f(5.96, 7.25);
    glVertex2f(6.01, 7.25);
    glVertex2f(6.04, 7.30);
    glVertex2f(6.09, 7.33);
    glVertex2f(6.15, 7.34);
    glVertex2f(6.22, 7.32);
    glVertex2f(6.24, 7.38);
    glVertex2f(6.29, 7.45);
    glVertex2f(6.36, 7.50);
    glVertex2f(6.45, 7.52);
    glVertex2f(6.54, 7.51);
    glVertex2f(6.60, 7.48);
    glVertex2f(6.64, 7.43);
    glVertex2f(6.65, 7.38);
    glVertex2f(6.71, 7.41);
    glVertex2f(6.77, 7.41);
    glVertex2f(6.82, 7.37);
    glVertex2f(6.84, 7.32);
    glVertex2f(6.82, 7.26);
    glVertex2f(6.88, 7.28);
    glVertex2f(6.95, 7.27);
    glVertex2f(6.99, 7.25);
    glVertex2f(6.99, 7.20);
    glVertex2f(6.93, 7.15);
    glVertex2f(6.86, 7.12);
    glVertex2f(6.77, 7.09);
    glVertex2f(6.68, 7.08);
    glVertex2f(6.53, 7.06);
    glVertex2f(6.35, 7.05);
    glVertex2f(6.21, 7.06);
    glVertex2f(6.05, 7.07);
    glVertex2f(5.92, 7.10);
    glVertex2f(5.81, 7.14);
    glVertex2f(5.81, 7.17);
glEnd();

glPopMatrix();

// Request redisplay for animation
glutPostRedisplay();


/**.......................................Cloud3..........................................**/

static float cloudOffsetX3 = 0.0;
float cloudWidth3 = 0.30;        // approximate width of the cloud
float sceneEndX = 13.42;         // right edge of the scene

// Update cloud position
cloudOffsetX3 += 0.001;           // adjust speed as needed
if (cloudOffsetX3 > sceneEndX + cloudWidth3)
    cloudOffsetX3 = -cloudWidth3; // reset to left once offscreen

glPushMatrix();
glTranslatef(cloudOffsetX3, 0.0, 0.0); // move cloud horizontally

// Cloud Drawing
glColor3ub(255, 255, 255);
glBegin(GL_POLYGON);
    glVertex2f(11.01f , 5.90f);
    glVertex2f(11.05f , 5.94f);
    glVertex2f(11.11f, 5.95f);
    glVertex2f(11.14f , 5.93f);
    glVertex2f(11.17f , 5.91f);
    glVertex2f(11.17f , 5.95f);
    glVertex2f(11.18f , 5.99f);
    glVertex2f(11.22f , 6.02f);
    glVertex2f(11.26f, 6.01f);
    glVertex2f(11.30f , 5.98f);
    glVertex2f(11.32f , 6.03f);
    glVertex2f(11.37f , 6.08f);
    glVertex2f(11.44f , 6.10f);
    glVertex2f(11.50f , 6.10f);
    glVertex2f(11.55f , 6.08f);
    glVertex2f(11.58f , 6.04f);
    glVertex2f(11.60f , 6.00f);
    glVertex2f(11.60f , 5.94f);
    glVertex2f(11.60f , 5.90f);
    glVertex2f(11.65f , 5.90f);
    glVertex2f(11.71f , 5.90f);
    glVertex2f(11.76f , 5.89f);
    glVertex2f(11.78f , 5.85f);
    glVertex2f(11.75f , 5.81f);
    glVertex2f(11.69f , 5.78f);
    glVertex2f(11.60f , 5.77f);
    glVertex2f(11.47f , 5.76f);
    glVertex2f(11.35f , 5.77f);
    glVertex2f(11.23f , 5.78f);
    glVertex2f(11.13f , 5.80f);
    glVertex2f(11.06f , 5.83f);
    glVertex2f(11.02f , 5.86f);
    glVertex2f(11.01f , 5.90f);
glEnd();

glPopMatrix();

glutPostRedisplay();

/*...............................Star.......................*/
// Draw stars if it's night
if (!day ) {
    drawTwinklingStars();
}

// Draw stars if it's night
if (!day ) {
    drawStars();
}



/**.......................................RoadSlim..........................................**/

//glColor3ub(153,153,153);
if (day){
    glColor3ub(153,153,153); // Light gray in day
}
else{
    glColor3ub(102,97,97);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(0, 0.85);
    glVertex2f(0, 0.95);
    glVertex2f(13.44, 0.95);
    glVertex2f(13.44, 0.85);
    glEnd();
/**.......................................RoadSlim2..........................................**/

//glColor3ub(201,193,197);
if (day){
    glColor3ub(201,193,197); // Light gray in day
}
else{
    glColor3ub(140,140,140);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(0, 0.95);
    glVertex2f(0, 1.2);
    glVertex2f(13.44, 1.2);
    glVertex2f(13.44, 0.95);
    glEnd();



   /**.......................................Shadow Building..........................................**/


    for (int i = 0; i < 3; i++) {
    // Part 1
    glPushMatrix();
    glTranslatef(i * 4.35f, 0.0f, 0.0f); // Shift by 3.80 per copy
    if (day) {
        glColor3ub(220, 248, 250);
    } else {
        glColor3ub(6, 15, 55);
    }
    glBegin(GL_POLYGON);
        glVertex2f(0, 3.68);
        glVertex2f(0.44, 3.68);
        glVertex2f(0.44, 2.06);
        glVertex2f(0, 2.06);
        glVertex2f(0, 3.68);
    glEnd();
    glPopMatrix();

    // Part 2
    glPushMatrix();
    glTranslatef(i * 4.40f, 0.0f, 0.0f); // Shift by 3.36 per copy
    if (day) {
        glColor3ub(227, 249, 253);
    } else {
        glColor3ub(15, 17, 52);
    }
    glBegin(GL_POLYGON);
        glVertex2f(0.50, 2.06);
        glVertex2f(0.50, 4.00);
        glVertex2f(0.60, 4.00);
        glVertex2f(0.60, 4.68);
        glVertex2f(0.72, 4.68);
        glVertex2f(0.72, 5.14);
        glVertex2f(1.41, 5.14);
        glVertex2f(1.41, 4.69);
        glVertex2f(1.52, 4.69);
        glVertex2f(1.52, 4.00);
        glVertex2f(1.62, 4.00);
        glVertex2f(1.62, 2.06);
        glVertex2f(0.50, 2.06);
    glEnd();
    glPopMatrix();

    // Part 3
    glPushMatrix();
    glTranslatef(i * 4.52f, 0.0f, 0.0f); // Shift by 3.68 per copy
    if (day) {
        glColor3ub(227, 249, 253);
    } else {
        glColor3ub(16, 15, 55);
    }
    glBegin(GL_POLYGON);
        glVertex2f(1.64, 4.30);
        glVertex2f(2.75, 4.30);
        glVertex2f(2.75, 2.06);
        glVertex2f(1.64, 2.06);
        glVertex2f(1.64, 4.30);
    glEnd();
    glPopMatrix();

    // Part 4
    glPushMatrix();
    glTranslatef(i * 4.60f, 0.0f, 0.0f); // Shift by 4.07 per copy
   if (day) {
        glColor3ub(220, 248, 250);
    } else {
        glColor3ub(6, 15, 55);
    }
    glBegin(GL_POLYGON);
        glVertex2f(3.29, 2.06);
        glVertex2f(3.29, 4.73);
        glVertex2f(3.42, 4.69);
        glVertex2f(3.53, 4.63);
        glVertex2f(3.63, 4.55);
        glVertex2f(3.74, 4.46);
        glVertex2f(3.84, 4.36);
        glVertex2f(3.91, 4.26);
        glVertex2f(3.97, 4.15);
        glVertex2f(4.01, 4.02);
        glVertex2f(4.05, 3.91);
        glVertex2f(4.07, 3.79);
        glVertex2f(4.08, 3.66);
        glVertex2f(4.09, 3.56);
        glVertex2f(4.10, 3.43);
        glVertex2f(4.11, 2.06);
        glVertex2f(3.29, 2.06);
    glEnd();
    glPopMatrix();
}

   //part5
   if (day) {
        glColor3ub(220, 248, 250);
    } else {
        glColor3ub(6, 15, 55);
    }
    glBegin(GL_POLYGON);
        glVertex2f(6.39, 2.06);
        glVertex2f(6.39, 4.96);
        glVertex2f(6.96, 5.69);
        glVertex2f(7.55, 4.96);
        glVertex2f(7.55, 2.06);
        glVertex2f(6.39, 2.06);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(6.91, 5.61);
        glVertex2f(6.91, 6.19);
        glVertex2f(6.9775548311173, 6.45);
        glVertex2f(7.0261035884789, 6.19);
        glVertex2f(7.02, 5.61);
        glVertex2f(6.91, 5.61);
    glEnd();






/**.......................................Building1..........................................**/
if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(0, 1.2);
    glVertex2f(0, 2.64);
    glVertex2f(3.44, 2.64);
    glVertex2f(3.44, 1.2);
    glVertex2f(0, 1.2);
glEnd();
glLineWidth(5);
 if (day){
    glColor3ub(220, 220, 220); // Light gray in day
 }
else{
    glColor3ub(196,196,196);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(0.69,2.64);
 glVertex2f(0.69,1.2);
glEnd();
glLineWidth(5);
if (day){
    glColor3ub(220, 220, 220); // Light gray in day
 }
else{
    glColor3ub(196,196,196);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(1.40,2.64);
 glVertex2f(1.40,1.2);
glEnd();
glLineWidth(5);
 if (day){
    glColor3ub(220, 220, 220); // Light gray in day
 }
else{
    glColor3ub(196,196,196);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(2.09,2.64);
 glVertex2f(2.09,1.2);
glEnd();
glLineWidth(5);
 if (day){
    glColor3ub(220, 220, 220); // Light gray in day
 }
else{
    glColor3ub(196,196,196);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(2.80,2.64);
 glVertex2f(2.80,1.2);
glEnd();

if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(0.17, 1.44);
    glVertex2f(0.17, 1.78);
    glVertex2f(3.27, 1.78);
    glVertex2f(3.27, 1.44);
    glVertex2f(0.17, 1.44);
glEnd();
if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(0.17, 2.00);
    glVertex2f(0.17, 2.35);
    glVertex2f(3.27, 2.35);
    glVertex2f(3.27, 2.00);
    glVertex2f(0.17, 2.00);
glEnd();



/**.......................................Building2..........................................**/

if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(3.43, 1.08);
    glVertex2f(3.44, 3.16);
    glVertex2f(5.48, 3.16);
    glVertex2f(5.48, 1.08);
    glVertex2f(3.43, 1.08);
glEnd();
if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(3.44, 3.16);
    glVertex2f(3.37, 3.25);
    glVertex2f(5.48, 3.25);
    glVertex2f(5.48, 3.16);
    glVertex2f(3.44, 3.16);
glEnd();
glLineWidth(5);
 if (day){
    glColor3ub(220, 220, 220); // Light gray in day
 }
else{
    glColor3ub(196,196,196);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(3.84,3.16);
 glVertex2f(3.84,1.08);
glEnd();
glLineWidth(5);
 if (day){
    glColor3ub(220, 220, 220); // Light gray in day
 }
else{
    glColor3ub(196,196,196);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(4.24,3.16);
 glVertex2f(4.24,1.08);
glEnd();
glLineWidth(5);
 if (day){
    glColor3ub(220, 220, 220); // Light gray in day
 }
else{
    glColor3ub(196,196,196);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(4.63,3.16);
 glVertex2f(4.63,1.08);
glEnd();
glLineWidth(5);
 if (day){
    glColor3ub(220, 220, 220); // Light gray in day
 }
else{
    glColor3ub(196,196,196);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(5.03,3.16);
 glVertex2f(5.03,1.08);
glEnd();
if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(3.44, 2.68);
    glVertex2f(3.44, 2.97);
    glVertex2f(5.47, 2.97);
    glVertex2f(5.47, 2.68);
    glVertex2f(3.44, 2.68);
glEnd();
if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(3.44, 2.22);
    glVertex2f(3.44, 2.51);
    glVertex2f(5.47, 2.51);
    glVertex2f(5.47, 2.22);
    glVertex2f(3.44, 2.22);
glEnd();
if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(3.44, 1.73);
    glVertex2f(3.44,  2.04);
    glVertex2f(5.47,  2.04);
    glVertex2f(5.47, 1.73);
    glVertex2f(3.44, 1.73);
glEnd();
if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(3.44, 1.28);
    glVertex2f(3.44,  1.55);
    glVertex2f(5.47,  1.55);
    glVertex2f(5.47, 1.28);
    glVertex2f(3.44, 1.28);
glEnd();


    /**.......................................Building3..........................................**/

if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(5.48, 1.07);
    glVertex2f(5.48, 3.71);
    glVertex2f(7.98, 3.71);
    glVertex2f(7.98, 1.07);
    glVertex2f(5.48, 1.07);
glEnd();

glLineWidth(8);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(5.41,3.71);
 glVertex2f(5.52,3.79);
 glVertex2f(5.65, 3.88);
 glVertex2f(5.83, 3.98);
 glVertex2f(6.00, 4.07);
 glVertex2f(6.16, 4.14);
 glVertex2f(6.30, 4.19);
 glVertex2f(6.43, 4.22);
 glVertex2f(6.58, 4.24);
 glVertex2f(6.72, 4.24);
 glVertex2f(6.85, 4.23);
 glVertex2f(7.02, 4.20);
 glVertex2f(7.14, 4.17);
 glVertex2f(7.29, 4.12);
 glVertex2f(7.46, 4.05);
 glVertex2f(7.60, 3.97);
 glVertex2f(7.72, 3.90);
 glVertex2f(7.86, 3.82);
 glVertex2f(7.94, 3.76);
 glVertex2f(8.01, 3.70);
glEnd();



if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(5.47, 3.71);
    glVertex2f(5.55, 3.76);
    glVertex2f(7.84, 3.76);
    glVertex2f(7.94, 3.71);
    glVertex2f(5.47, 3.71);
glEnd();

if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(5.48, 2.23);
    glVertex2f(5.48, 3.71);
    glVertex2f(7.98, 3.71);
    glVertex2f(7.98, 2.23);
    glVertex2f(5.48, 2.23);
glEnd();
if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_POLYGON);
    glVertex2f(5.55, 3.75);
    glVertex2f(5.92, 3.98);
    glVertex2f(5.98, 4.01);
    glVertex2f(6.18, 4.09);
    glVertex2f(6.43, 4.16);
    glVertex2f(6.43, 4.16);
    glVertex2f(6.67, 4.19);
    glVertex2f(6.92, 4.17);
    glVertex2f(6.97, 4.15);
    glVertex2f(7.18, 4.11);
    glVertex2f(7.43, 4.01);
    glVertex2f(7.50, 3.98);
    glVertex2f(7.84, 3.75);
    glVertex2f(5.55, 3.75);

glEnd();
glLineWidth(6);
if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(5.95,4.05);
 glVertex2f(5.95,3.75);
glEnd();
glLineWidth(6);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(6.46,4.20);
 glVertex2f(6.46,3.75);
glEnd();
glLineWidth(6);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(6.95,4.19);
 glVertex2f(6.95,3.75);
glEnd();

glLineWidth(6);
if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(7.46,4.10);
 glVertex2f(7.46,3.75);

glEnd();

glColor3ub(41,8,178);  //Text Dark Blue Building
    glBegin(GL_QUADS);
    glVertex2f(5.95, 3.71);
    glVertex2f(7.46, 3.71);
    glVertex2f(7.46, 3.24);
    glVertex2f(5.95, 3.24);
    glVertex2f(5.95, 3.71);
glEnd();
glLineWidth(6);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(5.47,3.23);
 glVertex2f(7.98,3.23);
glEnd();
glLineWidth(6);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(5.47,2.75);
 glVertex2f(7.98,2.75);
glEnd();
glLineWidth(6);
if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(7.46,3.71);
 glVertex2f(7.46,2.23);
glEnd();
glLineWidth(6);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(5.95,3.71);
 glVertex2f(5.95,2.23);
glEnd();
glLineWidth(6);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(6.46,3.23);
 glVertex2f(6.46,2.24);
glEnd();
glLineWidth(6);
if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(6.95,3.23);
 glVertex2f(6.95,2.24);
glEnd();

if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(5.48, 1.07);
    glVertex2f(5.48, 2.20);
    glVertex2f(5.92, 2.20);
    glVertex2f(5.92, 1.07);
    glVertex2f(5.48, 1.07);
glEnd();

if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(6.01, 1.07);
    glVertex2f(6.01, 2.16);
    glVertex2f(7.39, 2.16);
    glVertex2f(7.39, 1.07);
    glVertex2f(6.01, 1.07);
glEnd();
glLineWidth(4);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(6.69,2.16);
 glVertex2f(6.69,1.07);
glEnd();

if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(7.49, 1.07);
    glVertex2f(7.49, 2.20);
    glVertex2f(7.99, 2.20);
    glVertex2f(7.99, 1.07);
    glVertex2f(7.49, 1.07);
glEnd();



if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(5.42, 3.25);
    glVertex2f(5.42, 3.68);
    glVertex2f(5.48, 3.72);
    glVertex2f(5.48, 3.25);
     glVertex2f(5.43, 3.25);
glEnd();
if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(7.98, 1.07);
    glVertex2f(7.98, 3.71);
    glVertex2f(7.99, 3.66);
    glVertex2f(7.99, 1.07);
    glVertex2f(7.98, 1.07);
glEnd();

    /**.......................................Building4..........................................**/

                                  // === Draw Text Below Text ===
 glLoadIdentity(); // Reset for text
 glColor3f(235,235,235); // Black
 renderBitmapString(6.19, 3.38, 0,GLUT_BITMAP_TIMES_ROMAN_24, "AIRPORT");

if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(7.99, 2.99);
    glVertex2f(7.99, 3.27);
    glVertex2f(10.03, 3.27);
    glVertex2f(9.96, 2.99);
    glVertex2f(7.99, 2.99);
glEnd();
if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_POLYGON);
    glVertex2f(7.99, 3.16);
    glVertex2f(9.97, 3.16);
    glVertex2f(9.97, 2.99);
    glVertex2f(7.99, 2.99);
    glVertex2f(7.99, 3.16);
glEnd();


if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(7.99, 2.71);
    glVertex2f(9.97, 2.71);
    glVertex2f(9.97, 2.52);
    glVertex2f(7.99, 2.52);
    glVertex2f(7.99, 2.71);
glEnd();

if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(7.99, 2.23);
    glVertex2f(9.94, 2.24);
    glVertex2f(9.94, 2.04);
    glVertex2f(7.99, 2.04);
    glVertex2f(7.99, 2.23);
glEnd();

if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(7.99, 1.74);
    glVertex2f(9.94, 1.74);
    glVertex2f(9.94, 1.08);
    glVertex2f(7.99, 1.08);
    glVertex2f(7.99, 1.74);
glEnd();
glLineWidth(5);
 if (day){
    glColor3ub(220, 220, 220); // Light gray in day
 }
else{
    glColor3ub(196,196,196);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(8.38,3.16);
 glVertex2f(8.38,1.08);
glEnd();
glLineWidth(5);
 if (day){
    glColor3ub(220, 220, 220); // Light gray in day
 }
else{
    glColor3ub(196,196,196);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(8.78,3.16);
 glVertex2f(8.78,1.08);
glEnd();
glLineWidth(5);
 if (day){
    glColor3ub(220, 220, 220); // Light gray in day
 }
else{
    glColor3ub(196,196,196);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(9.19,3.16);
 glVertex2f(9.19,1.08);
glEnd();
glLineWidth(5);
if (day){
    glColor3ub(220, 220, 220); // Light gray in day
 }
else{
    glColor3ub(196,196,196);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(9.60,3.16);
 glVertex2f(9.60,1.08);
glEnd();
if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(7.99, 2.04);
    glVertex2f(9.94, 2.04);
    glVertex2f(9.94, 1.74);
    glVertex2f(7.99, 1.74);
    glVertex2f(7.99, 2.04);
glEnd();
if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(7.99, 2.52);
    glVertex2f(9.94, 2.52);
    glVertex2f(9.94, 2.24);
    glVertex2f(7.99, 2.23);
    glVertex2f(7.99, 2.52);
glEnd();
if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(7.99, 1.28);
    glVertex2f(7.99, 1.57);
    glVertex2f(9.93, 1.57);
    glVertex2f(9.93, 1.28);
    glVertex2f(7.99, 1.28);
glEnd();
if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(7.99, 2.99);
    glVertex2f(9.93, 2.99);
    glVertex2f(9.93, 2.71);
    glVertex2f(7.99, 2.71);
    glVertex2f(7.99, 2.99);
glEnd();


/**.......................................Building5..........................................**/

if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(9.94, 1.18);
    glVertex2f(9.94, 2.45);
    glVertex2f(13.42, 2.45);
    glVertex2f(13.42, 1.18);
    glVertex2f(9.94, 1.18);
glEnd();
//glColor3ub(202,75,66); //Red
if (day){
    glColor3ub(202,75,66); // Red
}
else{
    glColor3ub(160,35,26);    // Red at night
}
    glBegin(GL_QUADS);
    glVertex2f(9.94, 2.39);
    glVertex2f(9.94, 2.45);
    glVertex2f(13.42, 2.45);
    glVertex2f(13.42, 2.39);
    glVertex2f(9.94, 2.39);
glEnd();
if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(9.97, 1.95);
    glVertex2f(9.97, 2.16);
    glVertex2f(13.42, 2.16);
    glVertex2f(13.42, 1.95);
    glVertex2f(9.97, 1.95);
glEnd();
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(10.15, 1.95);
    glVertex2f(10.15, 2.16);
    glVertex2f(10.23, 2.16);
    glVertex2f(10.23, 1.95);
    glVertex2f(10.15, 1.95);
glEnd();
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(10.57, 1.95);
    glVertex2f(10.57, 2.16);
    glVertex2f(10.65, 2.16);
    glVertex2f(10.65, 1.95);
    glVertex2f(10.57, 1.95);
glEnd();
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(11.00, 1.95);
    glVertex2f(11.00, 2.16);
    glVertex2f(11.07, 2.16);
    glVertex2f(11.07, 1.95);
    glVertex2f(11.00, 1.95);
glEnd();
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(11.40, 1.95);
    glVertex2f(11.40, 2.16);
    glVertex2f(11.48, 2.16);
    glVertex2f(11.48, 1.95);
    glVertex2f(11.40, 1.95);
glEnd();
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(11.83, 1.95);
    glVertex2f(11.83, 2.16);
    glVertex2f(11.90, 2.16);
    glVertex2f(11.90, 1.95);
    glVertex2f(11.83, 1.95);
glEnd();
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(12.24, 1.95);
    glVertex2f(12.24, 2.16);
    glVertex2f(12.32, 2.16);
    glVertex2f(12.32, 1.95);
    glVertex2f(12.24, 1.95);
glEnd();
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(12.66, 1.95);
    glVertex2f(12.66, 2.16);
    glVertex2f(12.73, 2.16);
    glVertex2f(12.73, 1.95);
    glVertex2f(12.66, 1.95);
glEnd();
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(13.09, 1.95);
    glVertex2f(13.09, 2.16);
    glVertex2f(13.17, 2.16);
    glVertex2f(13.17, 1.95);
    glVertex2f(13.09, 1.95);
glEnd();

if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(9.97, 1.45);
    glVertex2f(9.97, 1.67);
    glVertex2f(13.42, 1.67);
    glVertex2f(13.42, 1.45);
    glVertex2f(9.97, 1.45);
glEnd();
//glColor3ub(202,75,66); //Red
if (day){
    glColor3ub(202,75,66); // Red
}
else{
    glColor3ub(160,35,26);    // Red at night
}
    glBegin(GL_QUADS);
    glVertex2f(9.94, 1.40);
    glVertex2f(9.94, 1.45);
    glVertex2f(13.42, 1.45);
    glVertex2f(13.42, 1.40);
    glVertex2f(9.94, 1.40);
glEnd();
//glColor3ub(105,157,166); //GlassShadow
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(10.15, 1.67);
    glVertex2f(10.15, 1.45);
    glVertex2f(10.23, 1.45);
    glVertex2f(10.23, 1.67);
    glVertex2f(10.15, 1.67);
glEnd();
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(10.57, 1.67);
    glVertex2f(10.57, 1.45);
    glVertex2f(10.65, 1.45);
    glVertex2f(10.65, 1.67);
    glVertex2f(10.57, 1.67);
glEnd();
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(10.99, 1.67);
    glVertex2f(10.99, 1.45);
    glVertex2f(11.07, 1.45);
    glVertex2f(11.07, 1.67);
    glVertex2f(10.99, 1.67);
glEnd();
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(11.40, 1.67);
    glVertex2f(11.40, 1.45);
    glVertex2f(11.48, 1.45);
    glVertex2f(11.48, 1.67);
    glVertex2f(11.40, 1.67);
glEnd();
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(11.82, 1.67);
    glVertex2f(11.82, 1.45);
    glVertex2f(11.89, 1.45);
    glVertex2f(11.89, 1.67);
    glVertex2f(11.82, 1.67);
glEnd();
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(12.24, 1.67);
    glVertex2f(12.24, 1.45);
    glVertex2f(12.31, 1.45);
    glVertex2f(12.31, 1.67);
    glVertex2f(12.24, 1.67);
glEnd();
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(12.66, 1.67);
    glVertex2f(12.66, 1.45);
    glVertex2f(12.73, 1.45);
    glVertex2f(12.73, 1.67);
    glVertex2f(12.66, 1.67);
glEnd();
if (day){
    glColor3ub(105,157,166); //GlassShadow
}
else{
    glColor3ub(54,80,108);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(13.09, 1.67);
    glVertex2f(13.09, 1.45);
    glVertex2f(13.15, 1.45);
    glVertex2f(13.15, 1.67);
    glVertex2f(13.09, 1.67);
glEnd();






//glColor3ub(202,75,66); //Red
if (day){
    glColor3ub(202,75,66); // Red
}
else{
    glColor3ub(160,35,26);    // Red at night
}
    glBegin(GL_QUADS);
    glVertex2f(9.94, 1.90);
    glVertex2f(9.94, 1.95);
    glVertex2f(13.42, 1.95);
    glVertex2f(13.42, 1.90);
    glVertex2f(9.94, 1.90);
glEnd();





/**....................................... Airplane..........................................**/

drawAirplane();





/**.......................................WatchBuilding5..........................................**/

if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(12.09, 2.45);
    glVertex2f(12.09, 4.27);
    glVertex2f(12.87, 4.27);
    glVertex2f(12.87, 2.45);
    glVertex2f(12.09, 2.45);
glEnd();
if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(12.09, 4.27);
    glVertex2f(12.05, 4.32);
    glVertex2f(12.92, 4.32);
    glVertex2f(12.88, 4.27);
    glVertex2f(12.09, 3.99);
glEnd();

if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(12.10, 4.32);
    glVertex2f(11.75, 5.12);
    glVertex2f(13.21, 5.12);
    glVertex2f(12.87, 4.32);
    glVertex2f(12.05, 4.32);
glEnd();
if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(11.73, 5.12);
    glVertex2f(11.76, 5.17);
    glVertex2f(13.18, 5.17);
    glVertex2f(13.21, 5.12);
    glVertex2f(11.73, 5.12);
glEnd();
if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(11.82, 5.17);
    glVertex2f(11.97, 5.29);
    glVertex2f(13.00, 5.29);
    glVertex2f(13.16, 5.17);
    glVertex2f(11.82, 5.17);
glEnd();
if (day){
    glColor3ub(101, 179, 250); // Bright glass blue
}
else{
    glColor3ub(69,129,142);   // Dimmer glass for night
}
    glBegin(GL_QUADS);
    glVertex2f(12.15, 5.29);
    glVertex2f(12.03, 5.60);
    glVertex2f(12.94, 5.60);
    glVertex2f(12.82, 5.29);
    glVertex2f(12.15, 5.29);
glEnd();
if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
    glBegin(GL_QUADS);
    glVertex2f(12.03, 5.60);
    glVertex2f(12.17, 5.70);
    glVertex2f(12.77, 5.70);
    glVertex2f(12.94, 5.60);
    glVertex2f(12.03, 5.60);
glEnd();
glColor3ub(92,70,70); //Antina
    glBegin(GL_QUADS);
    glVertex2f(12.38, 5.70);
    glVertex2f(12.38, 5.76);
    glVertex2f(12.58, 5.76);
    glVertex2f(12.58, 5.70);
     glVertex2f(12.38, 5.70);
glEnd();
glColor3ub(92,70,70); //Antina
    glBegin(GL_QUADS);
    glVertex2f(12.42, 5.76);
    glVertex2f(12.42, 5.79);
    glVertex2f(12.53, 5.79);
    glVertex2f(12.53, 5.76);
    glVertex2f(12.42, 5.76);
glEnd();
glColor3ub(92,70,70); //Antina
    glBegin(GL_QUADS);
    glVertex2f(12.47, 5.79);
    glVertex2f(12.47, 6.18);
    glVertex2f(12.50, 6.18);
    glVertex2f(12.50, 5.79);
    glVertex2f(12.47, 5.79);
glEnd();

glLineWidth(2);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(12.12,5.60);
 glVertex2f(12.22,5.29);
glEnd();
glLineWidth(2);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(12.26,5.60);
 glVertex2f(12.32,5.29);
glEnd();
glLineWidth(2);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(12.41,5.60);
 glVertex2f(12.42,5.29);
glEnd();
glLineWidth(2);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(12.55,5.60);
 glVertex2f(12.54,5.29);
glEnd();
glLineWidth(2);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(12.69,5.60);
 glVertex2f(12.64,5.29);
glEnd();
glLineWidth(2);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(12.84,5.60);
 glVertex2f(12.74,5.29);
glEnd();



glLineWidth(2);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(11.90,5.12);
 glVertex2f(12.16,4.32);
glEnd();
glLineWidth(2);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(12.13,5.12);
 glVertex2f(12.28,4.32);
glEnd();
glLineWidth(2);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(12.36,5.12);
 glVertex2f(12.41,4.32);
glEnd();
glLineWidth(2);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(12.60,5.12);
 glVertex2f(12.56,4.32);
glEnd();
glLineWidth(2);
 if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(12.83,5.12);
 glVertex2f(12.68,4.32);
glEnd();
glLineWidth(2);
if (day){
    glColor3ub(235, 235, 235); // Light gray in day
}
else{
    glColor3ub(182,182,182);    // Dark gray at night
}
 glBegin(GL_LINE_LOOP);
 glVertex2f(13.06,5.12);
 glVertex2f(12.80,4.32);
glEnd();





//glColor3ub(202,75,66); //Red
if (day){
    glColor3ub(202,75,66); // Red
}
else{
    glColor3ub(160,35,26);    // Red at night
}   glBegin(GL_QUADS);
    glVertex2f(12.09, 3.99);
    glVertex2f(12.09, 4.27);
    glVertex2f(12.87, 4.27);
    glVertex2f(12.87, 3.99);
    glVertex2f(12.09, 3.99);
glEnd();
//glColor3ub(202,75,66); //Red
if (day){
    glColor3ub(202,75,66); // Red
}
else{
    glColor3ub(160,35,26);    // Red at night
}
    glBegin(GL_QUADS);
    glVertex2f(12.09, 3.64);
    glVertex2f(12.87, 3.64);
    glVertex2f(12.87, 3.36);
    glVertex2f(12.09, 3.36);
    glVertex2f(12.09, 3.64);
glEnd();
//glColor3ub(202,75,66); //Red
if (day){
    glColor3ub(202,75,66); // Red
}
else{
    glColor3ub(160,35,26);    // Red at night
}
    glBegin(GL_QUADS);
    glVertex2f(12.09, 3.00);
    glVertex2f(12.87, 3.00);
    glVertex2f(12.87, 2.72);
    glVertex2f(12.09, 2.72);
    glVertex2f(12.09, 3.00);
glEnd();






/**.......................................RoadLight..........................................**/

for (int i = 0; i < 6; i++)
{
    glPushMatrix();                         // Save current transformation
    glTranslatef(i * 2.09, 0.0, 0.0);      // Translate along X axis (every 2.09 units)


    glLineWidth(5);
    glColor3ub(49,67,116); //Steel light line

    glBegin(GL_LINE_LOOP);
        glVertex2f(1.49,2.22);
        glVertex2f(1.49,1.02);
    glEnd();

    glColor3ub(49,67,116); // Base part
    glBegin(GL_POLYGON);
        glVertex2f(1.42, 1.00);
        glVertex2f(1.44, 1.02);
        glVertex2f(1.54, 1.02);
        glVertex2f(1.55, 1.00);
        glVertex2f(1.55, 0.98);
        glVertex2f(1.42, 0.98);
        glVertex2f(1.42, 1.00);
    glEnd();

    glLineWidth(2.5);
    glColor3ub(49,67,116); // Upper line
    glBegin(GL_LINE_LOOP);
        glVertex2f(1.49,2.22);
        glVertex2f(1.51,2.25);
        glVertex2f(1.53,2.27);
        glVertex2f(1.58,2.30);
        glVertex2f(1.59,2.31);
    glEnd();

    glColor3ub(49,67,116); // Right head
    glBegin(GL_POLYGON);
        glVertex2f(1.59, 2.32);
        glVertex2f(1.65, 2.35);
        glVertex2f(1.69, 2.36);
        glVertex2f(1.73, 2.37);
        glVertex2f(1.76, 2.36);
        glVertex2f(1.77, 2.35);
        glVertex2f(1.78, 2.34);
        glVertex2f(1.76, 2.32);
        glVertex2f(1.75, 2.32);
        glVertex2f(1.73, 2.33);
        glVertex2f(1.70, 2.32);
        glVertex2f(1.67, 2.32);
        glVertex2f(1.66, 2.31);
        glVertex2f(1.64, 2.30);
        glVertex2f(1.60, 2.30);
        glVertex2f(1.59, 2.32);
    glEnd();

    //glColor3ub(255,255,255); // Right head white
     if (day){
    glColor3ub(255,255,255);    // Day head white
}
else{
    glColor3ub(248,133,0);     // Night head white
}
    glBegin(GL_POLYGON);
        glVertex2f(1.64, 2.30);
        glVertex2f(1.66, 2.31);
        glVertex2f(1.67, 2.32);
        glVertex2f(1.70, 2.32);
        glVertex2f(1.73, 2.33);
        glVertex2f(1.75, 2.32);
        glVertex2f(1.76, 2.32);
        glVertex2f(1.72, 2.30);
        glVertex2f(1.68, 2.30);
        glVertex2f(1.64, 2.30);
    glEnd();

    glColor3ub(49,67,116); // Left head
    glBegin(GL_POLYGON);
        glVertex2f(1.37, 2.33);
        glVertex2f(1.36, 2.34);
        glVertex2f(1.32, 2.35);
        glVertex2f(1.29, 2.37);
        glVertex2f(1.27, 2.37);
        glVertex2f(1.25, 2.37);
        glVertex2f(1.22, 2.37);
        glVertex2f(1.20, 2.36);
        glVertex2f(1.19, 2.33);
        glVertex2f(1.20, 2.32);
        glVertex2f(1.23, 2.33);
        glVertex2f(1.25, 2.33);
        glVertex2f(1.26, 2.32);
        glVertex2f(1.28, 2.32);
        glVertex2f(1.31, 2.31);
        glVertex2f(1.32, 2.30);
        glVertex2f(1.37, 2.30);
        glVertex2f(1.37, 2.33);
    glEnd();

    //glColor3ub(255,255,255); // Left head white
      if (day){
    glColor3ub(255,255,255);    // Day head white
}
else{
    glColor3ub(248,133,0);     // Night head white
}
    glBegin(GL_POLYGON);
        glVertex2f(1.20, 2.32);
        glVertex2f(1.23, 2.33);
        glVertex2f(1.25, 2.33);
        glVertex2f(1.26, 2.32);
        glVertex2f(1.28, 2.32);
        glVertex2f(1.31, 2.31);
        glVertex2f(1.32, 2.30);
        glVertex2f(1.27, 2.30);
        glVertex2f(1.24, 2.31);
        glVertex2f(1.21, 2.32);
        glVertex2f(1.20, 2.32);
    glEnd();

    glLineWidth(2.5);
    glColor3ub(49,67,116); // Left connector
    glBegin(GL_LINE_LOOP);
        glVertex2f(1.49,2.22);
        glVertex2f(1.46,2.25);
        glVertex2f(1.44,2.27);
        glVertex2f(1.42,2.29);
        glVertex2f(1.39,2.31);
        glVertex2f(1.37,2.32);
    glEnd();

    glPopMatrix();                          // Restore transformation state
}

   /**.......................................TREE..........................................**/

for (int i = 0; i < 7; i++)
{
    if (i == 3) continue;  // Skip index 3

    glPushMatrix();                         // Save current transformation
    glTranslatef(i * 2.0, 0.0, 0.0);        // Translate along X axis (every 2 units)

    // Tree box white
    //glColor3ub(235,235,235);
     if (day){
    glColor3ub(235,235,235);    // Day green
}
else{
    glColor3ub(189,185,185);     // Night green (darker)
}
    glBegin(GL_POLYGON);
        glVertex2f(0.25, 1.01);
        glVertex2f(0.55, 1.01);
        glVertex2f(0.55, 0.96);
        glVertex2f(0.25, 0.96);
    glEnd();

    // Tree box green
    //glColor3ub(186,233,80);
      if (day){
    glColor3ub(186,233,80);    // Day green
}
else{
    glColor3ub(93,151,68);     // Night green (darker)
}
    glBegin(GL_POLYGON);
        glVertex2f(0.25, 1.01);
        glVertex2f(0.55, 1.01);
        glVertex2f(0.49, 1.05);
        glVertex2f(0.30, 1.05);
    glEnd();

    // Tree Wood
    glLineWidth(5);
    //glColor3ub(83,55,11);
     if (day){
    glColor3ub(151,88,23);    // Day green
}
else{
    glColor3ub(83,55,11);     // Night green (darker)
}
    glBegin(GL_LINE_LOOP);
        glVertex2f(0.41, 1.03);
        glVertex2f(0.41, 1.51);
    glEnd();

    // Tree Green Left
    if (day){
    glColor3ub(41,107,12);    // Day green
}
else{
    glColor3ub(20, 60, 20);     // Night green (darker)
}
    glBegin(GL_POLYGON);
        glVertex2f(0.22, 1.53);
        glVertex2f(0.2, 1.54);
        glVertex2f(0.18, 1.54);
        glVertex2f(0.16, 1.53);
        glVertex2f(0.14, 1.53);
        glVertex2f(0.13, 1.51);
        glVertex2f(0.11, 1.50);
        glVertex2f(0.10, 1.49);
        glVertex2f(0.10, 1.47);
        glVertex2f(0.10, 1.46);
        glVertex2f(0.09, 1.45);
        glVertex2f(0.07, 1.43);
        glVertex2f(0.07, 1.40);
        glVertex2f(0.07, 1.38);
        glVertex2f(0.09, 1.36);
        glVertex2f(0.10, 1.35);
        glVertex2f(0.12, 1.34);
        glVertex2f(0.15, 1.34);
        glVertex2f(0.17, 1.34);
        glVertex2f(0.19, 1.34);
        glVertex2f(0.21, 1.35);
        glVertex2f(0.22, 1.36);
        glVertex2f(0.23, 1.35);
        glVertex2f(0.24, 1.35);
        glVertex2f(0.26, 1.34);
        glVertex2f(0.29, 1.34);
        glVertex2f(0.31, 1.34);
        glVertex2f(0.33, 1.35);
        glVertex2f(0.34, 1.36);
        glVertex2f(0.36, 1.38);
        glVertex2f(0.38, 1.40);
        glVertex2f(0.39, 1.424);
        glVertex2f(0.4, 1.45);
        glVertex2f(0.38, 1.47);
        glVertex2f(0.37, 1.48);
        glVertex2f(0.36, 1.50);
        glVertex2f(0.34, 1.51);
        glVertex2f(0.22, 1.53);
    glEnd();

    // Tree Green Middle
    if (day){
    glColor3ub(41,107,12);    // Day green
    }
else{
    glColor3ub(20, 60, 20);     // Night green (darker)
}
    glBegin(GL_POLYGON);
        glVertex2f(0.22, 1.53);
        glVertex2f(0.2, 1.54);
        glVertex2f(0.19, 1.55);
        glVertex2f(0.18, 1.58);
        glVertex2f(0.19, 1.60);
        glVertex2f(0.13, 1.51);
        glVertex2f(0.21, 1.65);
        glVertex2f(0.23, 1.66);
        glVertex2f(0.23, 1.68);
        glVertex2f(0.23, 1.70);
        glVertex2f(0.24, 1.725);
         glVertex2f(0.26, 1.74);
        glVertex2f(0.28, 1.75);
        glVertex2f(0.30, 1.75);
        glVertex2f(0.33, 1.76);
        glVertex2f(0.37, 1.76);
        glVertex2f(0.40, 1.75);
        glVertex2f(0.42, 1.75);
        glVertex2f(0.45, 1.74);
        glVertex2f(0.47, 1.72);
        glVertex2f(0.49, 1.70);
        glVertex2f(0.50, 1.68);
        glVertex2f(0.51, 1.66);
        glVertex2f(0.51, 1.64);
        glVertex2f(0.51, 1.62);
        glVertex2f(0.53, 1.62);
        glVertex2f(0.55, 1.62);
        glVertex2f(0.56, 1.61);
        glVertex2f(0.57, 1.60);
        glVertex2f(0.43, 1.51);
        glVertex2f(0.41, 1.47);
        glVertex2f(0.34, 1.51);
        glVertex2f(0.22, 1.53);
    glEnd();

    // Tree Green Right
   if (day){
    glColor3ub(41,107,12);    // Day green
   }
else{
    glColor3ub(20, 60, 20);     // Night green (darker)
    }
    glBegin(GL_POLYGON);
        glVertex2f(0.56, 1.61);
        glVertex2f(0.62, 1.61);
         glVertex2f(0.66, 1.60);
        glVertex2f(0.68, 1.58);
        glVertex2f(0.70, 1.55);
         glVertex2f(0.69, 1.52);
        glVertex2f(0.72, 1.52);
        glVertex2f(0.73, 1.50);
        glVertex2f(0.74, 1.48);
        glVertex2f(0.74, 1.46);
        glVertex2f(0.74, 1.43);
        glVertex2f(0.72, 1.40);
        glVertex2f(0.70, 1.38);
        glVertex2f(0.67, 1.37);
        glVertex2f(0.64, 1.37);
        glVertex2f(0.60, 1.37);
        glVertex2f(0.58, 1.36);
        glVertex2f(0.56, 1.36);
        glVertex2f(0.51, 1.36);
        glVertex2f(0.48, 1.38);
        glVertex2f(0.45, 1.40);
        glVertex2f(0.43, 1.43);
        glVertex2f(0.41, 1.47);
        glVertex2f(0.43, 1.51);
        glVertex2f(0.56, 1.61);
    glEnd();

    glPopMatrix();                          // Restore transformation state
}

/**.......................................RoadLine..........................................**/
for (int i = 0; i < 17; i++)
{
    glPushMatrix();                         // Save current transformation
    glTranslatef(i * 0.80, 0.0, 0.0);        // Translate along X axis (every 2 units)

 if (day){
    glColor3ub(255,255,255);    // Red
   }
else{
    glColor3ub(200,200,200);     // Night yellow
    }
    glBegin(GL_POLYGON);
        glVertex2f(0.14, 0.50);
         glVertex2f(0.64, 0.50);
        glVertex2f(0.64, 0.42);
        glVertex2f(0.14, 0.42);
         glVertex2f(0.14, 0.50);
     glEnd();

 glPopMatrix();

}


/**....................................... Car..........................................**/
drawCAR();

drawCAR2();




glFlush();
}
// Timer callback for animation
void update(int value) {
    if (planeMoving) {
        airplane_x -= planeSpeed; // Move left

        if (airplane_x < -5.5f) {
            airplane_x = 14.0f;  // Reset from right
        }
    }

    glutPostRedisplay();              // Redraw
    glutTimerFunc(100, update, 0);    // Loop every 100ms
}

void update2(int value) {
    car_x -= car_speed;
    if (car_x < -13.5)  // wrap around the screen width
    {
        //car_x = 2.0;   // start from the left again
        car_x = 13.5;   // start from the left again
    }


    glutPostRedisplay();  // request redraw
    glutTimerFunc(10, update2, 0);  // call again ~60 FPS
}
void update3(int value) {
    if (car2Moving) {
        car2PositionX += 0.02f;
        if (car2PositionX > 13.5f) {
            car2PositionX = -13.5f;
        }
    }
    glutPostRedisplay();
    glutTimerFunc(10, update3, 0);
}



void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case 'd':  // Day mode
            day = true;
            break;
        case 'n':  // Night mode
            day = false;
            break;
        case 's':  // Toggle car2 movement
            car2Moving = !car2Moving;
            break;
        case 'f':  // Toggle fast/normal airplane speed
            fastSpeed = !fastSpeed;
            if (fastSpeed) {
                planeSpeed = 0.3f; // Fast
            } else {
                planeSpeed = 0.1f; // Normal
            }
            break;
        case 'p':  // Pause/resume airplane
            planeMoving = !planeMoving;
            break;
        case 'e':  // Exit
            exit(0);
            break;
    }
    glutPostRedisplay(); // Redraw the scene
}


int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(640, 480);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Airport Front View");
    glutDisplayFunc(display);
    glutTimerFunc(0, update, 0); // Start animation
    glutTimerFunc(0, update2, 0);
    glutTimerFunc(0, update3, 0);

    glutKeyboardFunc(keyboard);
    initGL();
    glutMainLoop();
    return 0;
}
